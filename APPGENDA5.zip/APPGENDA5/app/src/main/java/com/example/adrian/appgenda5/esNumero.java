package com.example.adrian.appgenda5;

/*
Esta clase es simplemente para usar el método comprobarNumero, como lo usaremos
en la clase NuevaCita y BorrarCitas, asi no ahorramos varias líneas de código.
 */

public class esNumero {

    public String cadena;

    esNumero(){

    }

    /*
   Este método devuelve un boolean y se le pasa como parametro un String.
   Creamos la variable booleana resultado para guardar el resultado de bloque try-catch
   Si al hacer el casting, se puede convertir el valor String en un valor de tipo
   int, quiere decir que solo hay números. Si pasa lo contrario, quiere decir que hay un caracter
   que no es un número. Si se queda en el bloque try, igualamos la variable resultado a true,
   si se queda en el bloque catch la igualamos a false. Por último, devolvemos el valor de la
   variable resultado.
    */
    public static boolean comprobarNumero(String cadena){

        boolean resultado;

        try{
            Integer.parseInt(cadena);
            resultado = true;
        }catch (NumberFormatException excepcion){
            resultado = false;
        }

        return resultado;
    }
}

