package com.example.adrian.appgenda3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;


public class MainActivity extends AppCompatActivity {

    Button nuevaCita;
    Button verCitas;
    Button borrarCitas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nuevaCita = (Button) findViewById(R.id.nuevaCita);
        verCitas = (Button) findViewById(R.id.citas2);
        borrarCitas = (Button) findViewById(R.id.borrar);

        nuevaCita.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent i = new Intent(MainActivity.this, NuevaCita.class);
                startActivity(i);
            }

        });

        verCitas.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent i = new Intent(MainActivity.this, VerCitas.class);
                startActivity(i);
            }

        });

        borrarCitas.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, BorrarCitas.class);
                startActivity(i);
            }
        });
    }
}
