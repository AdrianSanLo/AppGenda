package com.example.adrian.appgenda3;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;
import android.content.Intent;

public class NuevaCita extends AppCompatActivity {

    Button volver;
    Button guardar;
    EditText numeroCita;
    EditText textoCita;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_cita);

        volver = (Button) findViewById(R.id.volver);
        guardar = (Button) findViewById(R.id.guardar);
        numeroCita = (EditText) findViewById(R.id.numeroCita);
        textoCita = (EditText) findViewById(R.id.textoCita);


        guardar.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){

                guardarCitas();

            }

        });

        volver.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent i = new Intent(NuevaCita.this, MainActivity.class);
                startActivity(i);
            }

        });

    }

    public void guardarCitas(){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminCitas");

        SQLiteDatabase bd = admin.getWritableDatabase();
        String codigo = numeroCita.getText().toString();
        String cita = textoCita.getText().toString();

        bd.execSQL("INSERT INTO citas(numeroCita, textoCita) VALUES('"+codigo+"', '"+cita+"')");

        bd.close();

        numeroCita.setText("");
        textoCita.setText("");

        Toast.makeText(this,"Se guardó la cita", Toast.LENGTH_SHORT).show();
    }

}
