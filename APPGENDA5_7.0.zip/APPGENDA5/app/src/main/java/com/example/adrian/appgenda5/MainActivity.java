package com.example.adrian.appgenda5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

/**
 * Activity principal la cual contendrá los botones para acceder a las diferentes funcionalidades
 * de la agenda (nueva cita, borrar citas y ver citas)
 *
 * @author Adrian
 * @version 7.0
 */

public class MainActivity extends AppCompatActivity {

    /**
     * Creamos los botones que va a tener el activity
     */

    Button nuevaCita;
    Button verCitas;
    Button borrarCitas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /**
         * Ocultamos la barra con el nombre de la aplicación
         */

        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /**
         *A cada botón creado le asginamos el ID que tiene en el documento XML del Activity.
         */

        nuevaCita = (Button) findViewById(R.id.nuevaCita);
        verCitas = (Button) findViewById(R.id.citas2);
        borrarCitas = (Button) findViewById(R.id.borrar);

        /**Creamos un evento Click (si hacemos Click en un botón
         * (es lo mismo que pulsarlo físicamente con el dedo)
         * nos llevará a un Activity nuevo, dependiendo de lo que queramos hacer)
         */

        /**
         * Este evento nos lleva al Activity de crear una cita nueva.
         */

        nuevaCita.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent i = new Intent(MainActivity.this, NuevaCita.class);
                startActivity(i);

            }

        });

        /**
         * Este evento nos lleva al Activity de ver las citas ya creadas.
         */

        verCitas.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent i = new Intent(MainActivity.this, VerCitas.class);
                startActivity(i);
            }

        });

        /**
         * Este evento nos lleva al Activity de borrar las citas ya creadas.
         */

        borrarCitas.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, BorrarCitas.class);
                startActivity(i);
            }
        });
    }
}

