package com.example.adrian.appgenda5;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Esta clase es usada para trabajar con la base de datos, creándola, haciendo consultas, borrando datos,
 * e insertando nuevos datos.
 *
 * @author Adrian
 * @version 7.0
 */

/**
 * Esta clase es usada para trabajar con la base de datos, haciendo consultas, borrando datos
 * e insertando nuevos datos.
 */
public class AdminSQLiteOpenHelper extends SQLiteOpenHelper{

    /**
     * Guardamos la sentencia de creación de la tabla en un string
     */
    String sql = "CREATE TABLE citas (numeroCita TEXT, textoCita TEXT, fechaCita TEXT);";

    /**
     * Constructor por parámetros de la clase
     * @param context
     * @param name
     */
    public AdminSQLiteOpenHelper(Context context, String name){
        super(context, name, null, 1);
    }

    /**
     * Métodos
     */
    @Override
    /**
     * Este método se le pasa como parametro un objeto de la clase SQLiteDatabase.
     * Dentro de él se ejecuta el método execSQL que se le pasa como parámetro
     * el string con la sentencia de creación de la base de datos.
     *
     * @param db
     * @return este metodo no devuelve ningun valor
     */
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sql);
    }

    @Override
    /**
     * Este método se usa cuando la base de datos sufre algún cambio.
     *
     * @param db
     * @param oldVersion
     * @param newVersion
     *
     * @return este metodo no devuelve ningun valor
     */
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS citas");
        db.execSQL(sql);

    }
}

