package com.example.adrian.appgenda3;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import android.content.*;

public class BorrarCitas extends AppCompatActivity {

    Button volver;
    Button borrar;
    EditText et3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Ocultamos la barra con el nombre de la aplicación
        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrar_citas);

        volver = (Button) findViewById(R.id.volver3);
        borrar = (Button) findViewById(R.id.borrar);
        et3 = (EditText) findViewById(R.id.et3);

        volver.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                Intent i = new Intent(BorrarCitas.this, MainActivity.class);
                startActivity(i);
            }
        });

        borrar.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                borrarDatos();
            }
        });
    }

    private void borrarDatos() {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminCitas");

        SQLiteDatabase bd = admin.getWritableDatabase();

        String num = et3.getText().toString();
        int cant = bd.delete("citas", "numeroCita=" + num,null);
        bd.close();

        if(et3.getText().toString().equals(" ")){
            Toast.makeText(this, "No se ha introducido ningún número de cita", Toast.LENGTH_SHORT).show();
        }

        if(cant == 1){
            Toast.makeText(this, "Cita borrada", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No exite una cita con ese numero", Toast.LENGTH_SHORT).show();
        }

    }
}
