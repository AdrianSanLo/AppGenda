package com.example.adrian.appgenda3;

import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;
import android.content.Intent;
public class NuevaCita extends AppCompatActivity {

    Button volver;
    Button guardar;
    EditText numeroCita;
    EditText textoCita;
    TextView textoFecha;
    CalendarView calendario;
    public String fechaUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Ocultamos la barra con el nombre de la aplicación
        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_cita);

        volver = (Button) findViewById(R.id.volver);
        guardar = (Button) findViewById(R.id.guardar);
        numeroCita = (EditText) findViewById(R.id.numeroCita);
        textoCita = (EditText) findViewById(R.id.textoCita);
        calendario = (CalendarView) findViewById(R.id.calendario);
        textoFecha = (TextView) findViewById(R.id.textoFecha);

        guardar.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                guardarCitas();

            }

        });

        volver.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent i = new Intent(NuevaCita.this, MainActivity.class);
                startActivity(i);
            }

        });

        calendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String dia = Integer.toString(dayOfMonth);
                String mes = Integer.toString(month);
                String anyo = Integer.toString(year);
                String fecha = dia + "/" + mes + "/" + anyo;
                fechaUsuario = fecha;
            }

        });

    }

    //Función que guarda las citas en la base de datos
    public void guardarCitas(){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminCitas");

        textoFecha.setText(fechaUsuario);

        SQLiteDatabase bd = admin.getWritableDatabase();
        String codigo = numeroCita.getText().toString();
        String cita = textoCita.getText().toString();

        String insert = "INSERT INTO citas(numeroCita, textoCita, fechaCita) VALUES('"+codigo+"', '"+cita+"', '"+fechaUsuario+"');";

        System.out.println("Sentencia insert: " + insert);

        bd.execSQL(insert);

        bd.close();

        numeroCita.setText("");
        textoCita.setText("");

        Toast.makeText(this,"Se guardó la cita" , Toast.LENGTH_SHORT).show();
    }

}
