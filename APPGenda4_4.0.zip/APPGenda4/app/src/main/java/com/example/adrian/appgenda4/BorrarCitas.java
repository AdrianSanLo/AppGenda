package com.example.adrian.appgenda4;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import android.content.*;

public class BorrarCitas extends AppCompatActivity {

    //Creamos los botones, textos y widgets que nos harán falta para el activity.
    Button volver;
    Button borrar;
    EditText et3;

    /*
     Creamos el evento que hace que cuando le demos click al botón guardar
     llama al método guardarCitas(explicado más abajo)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Ocultamos la barra con el nombre de la aplicación
        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrar_citas);

        //A cada botón creado le asginamos el ID que tiene en el documento XML del Activity.
        volver = (Button) findViewById(R.id.volver3);
        borrar = (Button) findViewById(R.id.borrar);
        et3 = (EditText) findViewById(R.id.et3);

        //Evento para volver al activity principal.
        volver.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                Intent i = new Intent(BorrarCitas.this, MainActivity.class);
                startActivity(i);
            }
        });

        //Evento para borrar las citas de la base de datos, en este evento usamos el metodo borrarDatos.
        borrar.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                borrarDatos();
            }
        });
    }

    //Funcion que borra las citas de la base de datos en función del numero de cita introducido por el usuario.
    private void borrarDatos() {
         /*
        Creamos el objeto admin de la clase AdminSQLiteHelper para poder trabajar con la base de datos.
         */
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminCitas");

          /*
        En la siguiente línea lo que hacemos es poner la base de datos en modo escritura.
        Para poder escribir y borrar los datos que obtendremos del calendario, el numero de cita y la cita.
         */
        SQLiteDatabase bd = admin.getWritableDatabase();

        //Cogemos el texto de la etiqueta y lo convertimos a String
        String num = et3.getText().toString();

        /*
        Aqui creamos un objeto de la clase esNumero llamado comprobación, el objeto, lo usaremos
        con la función comprobarNumero que está en la clase esNumero para comprobar si el String
        num, tiene letras o no.
         */
        esNumero comprobacion = new esNumero();

        /*
        En el siguiente if comprueba (el método esta explicado en la clase) que num no contenga letras
        o espacios en blanco y que se haya introducido al menos un caracter. En caso de que se de la
        condición se muestra un mensaje avisando al usuario. En el else se hace la consulta, guardamos
        el valor que devuelve el entero en una variable de tipo entero, si la condición es distinta de 1
        muestra un mensaje si no muestra el mensaje de cita borrada.
         */
        if(num.trim().length() == 0 || comprobacion.comprobarNumero(num) == false){
            //Mensaje de aviso.
            Toast.makeText(this, "No se ha introducido ningún número o el número contiene letras o espacios en blanco. ", Toast.LENGTH_SHORT).show();
        } else {
            int cant = bd.delete("citas", "numeroCita=" + num,null); //Guardamos el resultado de la consulta en variable entera cant.
            bd.close(); //Cerramos la conexion con la base de datos.

            if(cant !=1){
                //Mensaje de aviso.
                Toast.makeText(this, "No exite una cita con ese numero", Toast.LENGTH_SHORT).show();
            } else {
                //Mensaje de aviso.
                Toast.makeText(this, "Cita borrada", Toast.LENGTH_SHORT).show();
                }
            }
        et3.setText("");
    }

}
