package com.example.adrian.appgenda4;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.database.*;

public class VerCitas extends AppCompatActivity {
    Button volver2;
    TextView et1;
    Button ver;
    ListView lista;
    CalendarView calendario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Ocultamos la barra con el nombre de la aplicación
        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_citas);

        volver2 = (Button) findViewById(R.id.volver2);
        ver = (Button) findViewById(R.id.ver);

        volver2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent i = new Intent(VerCitas.this, MainActivity.class);
                startActivity(i);
            }

        });

        ver.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                consultar();
            }
        });
    }

    public void consultar(){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminCitas");

        SQLiteDatabase bd = admin.getWritableDatabase();

        LinearLayout lista = (LinearLayout)findViewById(R.id.lista);

        Cursor fila = bd.rawQuery("select * from citas", null);


        if (fila.moveToFirst()) {

            do{
                System.out.println("Entra en el doWhile");
                et1 = new TextView(this);
                et1.setText((fila.getString(0)) + "  -  " + (fila.getString(1) + "  -  " + (fila.getString(2))));
                et1.setTextSize(20);
                lista.addView(et1);

            } while (fila.moveToNext());

            Toast.makeText(this, "Mostrando las citas", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(this, "No hay citas", Toast.LENGTH_SHORT).show();
            System.out.println("Entra en el Else");
        }

        bd.close();

    }


}
