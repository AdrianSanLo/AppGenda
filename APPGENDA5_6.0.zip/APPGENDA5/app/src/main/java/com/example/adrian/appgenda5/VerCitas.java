package com.example.adrian.appgenda5;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.database.*;

public class VerCitas extends AppCompatActivity {

    //Creamos los botones, textos y widgets que nos harán falta para el activity.
    Button volver2;
    TextView et1;
    Button ver;
    ListView lista;
    CalendarView calendario;

    /*
  Creamos el evento que hace que cuando le demos click al botón ver citas
  llama al método consultar(explicado más abajo)
  */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Ocultamos la barra con el nombre de la aplicación
        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_citas);

        //A cada botón creado le asginamos el ID que tiene en el documento XML del Activity.
        volver2 = (Button) findViewById(R.id.volver2);
        ver = (Button) findViewById(R.id.ver);

        //Evento para volver al activity principal.
        volver2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent i = new Intent(VerCitas.this, MainActivity.class);
                startActivity(i);
            }

        });

        /*
        Creamos el evento que hace que cuando le demos click al botón ver citas
        llama al método consultar(explicado más abajo)
        */
        ver.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                consultar();
            }
        });
    }

    //Este metodo lo que hace es mostrar el resultado de la consulta en una lista.
    public void consultar(){
          /*
        Creamos el objeto admin de la clase AdminSQLiteHelper para poder trabajar con la base de datos.
         */
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminCitas");

         /*
        En la siguiente línea lo que hacemos es poner la base de datos en modo escritura.
        Para poder escribir y borrar los datos que obtendremos del calendario, el numero de cita y la cita.
         */
        SQLiteDatabase bd = admin.getWritableDatabase();

        //Creamos el objeto lista, donde mostraremos el resultado de la consulta.
        LinearLayout lista = (LinearLayout)findViewById(R.id.lista);

        //Creamos un objeto Cursor el cual tendrá como valor el resultado de la consulta.
        Cursor fila = bd.rawQuery("select * from citas", null);


        /*
        Primero comprobamos que la et1 no este vacío, es decir, que su valor no sea null,
        luego en el siguiente if  comprobamos que la tabla que estamos consultando tiene datos
        si la consulta devuelve un resultado entonces entra en el bucle do-while
        que lo que hace es concatenar los valores de cada columna, una vez concatenado,
        muestra el resultado en la etiqueta de texto. Para la condicion del while, usamos la función
        moveToNext que se va moviendo por los registros de la base de datos, saldrá del bucle
        cuando el cursos no siga moviendose por los registros. Cuando sale del do-while muestra un
        mensaje.
        Si la condición del if no devuelve nada, entonces va al else que muestra el mensaje de
        que no hay citas.
         */

        if (et1 == null) {
            if (fila.moveToFirst()) {

                do{
                    et1 = new TextView(this);
                    et1.setText((fila.getString(0)) + "  -  " + (fila.getString(1) + "  -  " + (fila.getString(2))));
                    et1.setTextSize(20);
                    lista.addView(et1);

                } while (fila.moveToNext());

                //Mensaje de aviso.
                Toast.makeText(this, "Mostrando las citas", Toast.LENGTH_SHORT).show();
            } else {
                //Mensaje de aviso.
                Toast.makeText(this, "No hay citas", Toast.LENGTH_SHORT).show();

            }

        }  else {
            Toast.makeText(this, "Se están mostrando las citas", Toast.LENGTH_SHORT).show();

        }

        bd.close(); //Cerramos la conexión con la base de datos.
        System.out.println(et1);
    }


}
