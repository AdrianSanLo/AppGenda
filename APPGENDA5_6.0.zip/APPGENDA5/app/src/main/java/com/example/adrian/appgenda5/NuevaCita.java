package com.example.adrian.appgenda5;

import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;
import android.content.Intent;

public class NuevaCita extends AppCompatActivity {


    //Creamos los botones, textos y widgets que nos harán falta para el activity.
    Button volver;
    Button guardar;
    EditText numeroCita;
    EditText textoCita;
    TextView textoFecha;
    CalendarView calendario;

    //Esta variable pública la usaremos para almacenar la fecha que el usuario marque en el calendario.
    public String fechaUsuario ;

    //Creamos el activity que se va a ejecutar
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Ocultamos la barra con el nombre de la aplicación
        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_cita);

        //A cada botón creado le asginamos el ID que tiene en el documento XML del Activity.
        volver = (Button) findViewById(R.id.volver);
        guardar = (Button) findViewById(R.id.guardar);
        numeroCita = (EditText) findViewById(R.id.numeroCita);
        textoCita = (EditText) findViewById(R.id.textoCita);
        calendario = (CalendarView) findViewById(R.id.calendario);


        /*
        Creamos el evento que hace que cuando le demos click al botón guardar
        llama al método guardarCitas(explicado más abajo)
         */
        guardar.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                guardarCitas();

            }

        });

        //Creamos el evento para volver al activity principal
        volver.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent i = new Intent(NuevaCita.this, MainActivity.class);
                startActivity(i);
            }

        });

        /*
        Este evento lo que hace es que cuando seleccionamos una fecha del calendario,
        extrae el día, el mes y el año.
         */
        calendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String dia = Integer.toString(dayOfMonth); //Hacemos un casting, convertimos el número en un String.

                /*
                Hacemos un casting, convertimos el número en un String.
                Al mes hay que sumarle 1 porque los meses empiezan en 0
                (Enero sería 0, Febrero 1 y así sucesivamente).
                 */
                String mes = Integer.toString(month + 1);

                String anyo = Integer.toString(year); //Hacemos un casting, convertimos el número en un String.

                //En la variable fecha concatenamos todas las variables anteriormente creadas.
                String fecha = dia + "/" + mes + "/" + anyo;
                fechaUsuario = fecha;
            }

        });

    }

    //Función que guarda las citas en la base de datos
    public void guardarCitas(){
        /*
        Creamos el objeto admin de la clase AdminSQLiteHelper para poder trabajar con la base de datos.
         */
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminCitas");
        /*
        En la siguiente línea lo que hacemos es poner la base de datos en modo escritura.
        Para poder escribir y borrar los datos que obtendremos del calendario, el numero de cita y la cita.
         */
        SQLiteDatabase bd = admin.getWritableDatabase();

        /*
        Obtenemos el texto de numeroCita y textoCita, los pasamos a String y los guardamos en las
        varibles codigo y cita respectivamente.
         */
        String codigo = numeroCita.getText().toString();
        String cita = textoCita.getText().toString();

        //Control de errores
        /*
        En la condición del siguiente if lo que hacemos es usar la funcion esNumero (creada más adelante)
        para comprobar si en el código introducido por el usuario no hay letras, ya que solo se pueden
        guardar números. En caso de que el codigo introducido sólo contengan números entra en el if
        siguiente y comprueba si la fecha ha sido marcada o no, en caso de que haya sido marcada,
        cambia el valor de la variable fechaUsuario por "Sin fecha" y ejecuta la sentencia de inserción
        de datos en la base de datos. Si se ha seleccionado una fecha, no se cambia el valor de la variable
        se ejecuta la sentencia de inserción de datos en base de datos. Por último, el último else
        lo que hace es que si el número de cita tiene letras o espacios en blanco, avisa al usuario
        de que el número de citas no puede contener letras.
         */
        esNumero comprobar = new esNumero();

        if(comprobar.comprobarNumero(codigo) == true){

            if(fechaUsuario == null){
                //Variable String con la sentencia que ejecutaremos.
                String insert = "INSERT INTO citas(numeroCita, textoCita, fechaCita) VALUES('"+codigo+"', '"+cita+"', '"+fechaUsuario+"');";


                //Insertamos los datos.
                bd.execSQL(insert);

                //Cerramos la base de datos.
                bd.close();

                //Quitamos los valores que el usuario introdujo.
                numeroCita.setText("");
                textoCita.setText("");
                fechaUsuario = "Sin fecha";

                //Mensaje de aviso.
                Toast.makeText(this,"Se guardó la cita sin fecha." , Toast.LENGTH_SHORT).show();

            } else {
                //Variable String con la sentencia que ejecutaremos
                String insert = "INSERT INTO citas(numeroCita, textoCita, fechaCita) VALUES('"+codigo+"', '"+cita+"', '"+fechaUsuario+"');";

                //Insertamos los datos.
                bd.execSQL(insert);

                //Cerramos la base de datos.
                bd.close();

                //Quitamos los valores que el usuario introdujo.
                numeroCita.setText("");
                textoCita.setText("");

                //Mensaje de aviso.
                Toast.makeText(this,"Se guardó la cita" , Toast.LENGTH_SHORT).show();
            }

        } else {
            //Mensaje de aviso en caso de que el usuario haya introducido letras en el numero de cita.
            Toast.makeText(this,"El número de cita no puede contener letras o espacios en blanco." , Toast.LENGTH_SHORT).show();
        }
    }

}